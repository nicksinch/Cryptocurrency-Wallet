package bg.sofia.uni.fmi.mjt.crypto;

import bg.sofia.uni.fmi.mjt.crypto.client.CryptoClient;
import bg.sofia.uni.fmi.mjt.crypto.command.Command;
import bg.sofia.uni.fmi.mjt.crypto.command.CommandCreator;
import bg.sofia.uni.fmi.mjt.crypto.command.CommandExecutor;
import bg.sofia.uni.fmi.mjt.crypto.exceptions.CryptoClientException;
import bg.sofia.uni.fmi.mjt.crypto.server.Server;
import bg.sofia.uni.fmi.mjt.crypto.storage.Asset;
import bg.sofia.uni.fmi.mjt.crypto.storage.InMemoryStorage;
import bg.sofia.uni.fmi.mjt.crypto.storage.Storage;
import bg.sofia.uni.fmi.mjt.crypto.storage.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonWriter;

import java.io.*;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) throws IOException {
        Storage st = new InMemoryStorage();
        CommandExecutor cmEx = new CommandExecutor(st);
        Server s = new Server(7777, cmEx);
        s.start();
        //Path databasePath = Paths.get("/home/nicksinch/IdeaProjects/CryptoCurrency-Wallet/src/bg/sofia/uni/fmi/mjt/crypto/storage/userDataBase.json");
//        User u = new User("Misho", "1234");
//        try (Writer writer = new FileWriter(String.valueOf(databasePath))) {
//            Gson gson = new GsonBuilder().create();
//            gson.toJson(u, writer);
//        }
//        catch (IOException e){
//
//        }
        //String content = Files.readString(databasePath, StandardCharsets.US_ASCII);
        //System.out.println(content);
//        Gson gson = new GsonBuilder().create();
//        try (Reader reader = new FileReader(String.valueOf(databasePath));
//             Writer writer = new FileWriter(String.valueOf(databasePath))) {
//
//            System.out.println(reader);
////            User[] userArray = gson.fromJson(reader, User[].class);
////            Type userListType = new TypeToken<ArrayList<User>>(){}.getType();
////            String json = gson.fromJson(String.of(reader));
////            List<User> users = gson.fromJson(reader, userListType);
////            if(users != null) {
////                users.add(u);
////            }
//            //userArray.
//            gson.toJson(users, writer);
//        }
//        catch (IOException e) {
//
//        }
    }
}
