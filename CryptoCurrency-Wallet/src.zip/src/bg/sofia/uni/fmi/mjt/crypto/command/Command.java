package bg.sofia.uni.fmi.mjt.crypto.command;

public record Command(String command, String[] arguments){
}
